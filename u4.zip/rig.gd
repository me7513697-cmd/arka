class_name Rig
extends Node2D
## شخصية بصور حقيقية (4 وضعيات: وقوف/مشي/لكمة/ركلة) بتتحرك بالتحويلات.
## بتبص يمين دايمًا (الـ Fighter هو اللي بيقلبها). نقطة الارتكاز تحت الرجلين.

var char_id := ""
var animation := "idle"
var t := 0.0
var playing := true
var speed_scale := 1.0
var special_type := "rush"
var tex := {}
var spr: Sprite2D
var cw := 400.0
var ch := 330.0
var _pose_name := ""


func setup(id: String) -> void:
	char_id = id
	special_type = GameData.CHARACTERS[id]["special_type"]
	for p in ["idle", "walk", "punch", "kick"]:
		tex[p] = GameData.pose_tex(id, p)
	var t0: Texture2D = tex["idle"]
	cw = float(tex["kick"].get_width())
	ch = float(t0.get_height())
	spr = Sprite2D.new()
	spr.centered = false
	spr.texture = t0
	add_child(spr)
	_update()


func play(anim: String) -> void:
	var cfg: Dictionary = GameData.ANIMS[anim]
	if animation == anim and playing and cfg["loop"] and _pose_name == "":
		return
	animation = anim
	t = 0.0
	playing = true
	_pose_name = ""
	_update()


func show_pose(pose_name: String) -> void:
	_pose_name = pose_name
	playing = false
	_update()


func pause() -> void:
	playing = false


func make_ghost() -> Rig:
	var g := Rig.new()
	g.setup(char_id)
	g.animation = animation
	g.t = t
	g._pose_name = _pose_name
	g.playing = false
	g._update()
	return g


func _process(delta: float) -> void:
	if playing:
		t += delta * speed_scale
	_update()


# ---------- الوضعيات ----------
func _st(tx: String, pos := Vector2.ZERO, rot := 0.0, sc := Vector2.ONE, mod := Color.WHITE) -> Dictionary:
	return {"tex": tx, "pos": pos, "rot": rot, "sc": sc, "mod": mod}


static func _ss(a: float, b: float, x: float) -> float:
	var w := clampf((x - a) / maxf(b - a, 0.0001), 0.0, 1.0)
	return w * w * (3.0 - 2.0 * w)


func _pose() -> Dictionary:
	if _pose_name == "hurt":
		var j := sin(t * 40.0) * 2.0
		return _st("idle", Vector2(-14.0 + j, 0.0), -0.17, Vector2(0.97, 1.02))
	var cfg: Dictionary = GameData.ANIMS[animation]
	var dur: float = float(cfg.get("dur", 1.0))
	var p := clampf(t / dur, 0.0, 1.0)
	match animation:
		"idle":
			var b := sin(t * TAU / 1.2)
			return _st("idle", Vector2.ZERO, 0.0, Vector2(1.0 - 0.006 * b, 1.0 + 0.012 * b))
		"walk":
			var ph := t * TAU / 0.7
			return _st("walk", Vector2(0.0, -absf(sin(ph)) * 5.0), sin(ph) * 0.015)
		"run":
			var ph2 := t * TAU / 0.45
			return _st("walk", Vector2(0.0, -absf(sin(ph2)) * 9.0), 0.10 + sin(ph2) * 0.02)
		"block":
			return _st("idle", Vector2(-6.0, 0.0), -0.06, Vector2(1.05, 0.92), Color(0.82, 0.9, 1.0))
		"punch":
			return _strike("punch", p, 0.18, 0.66, 14.0, -0.08, 0.03)
		"kick":
			return _strike("kick", p, 0.2, 0.72, 10.0, -0.09, -0.04)
		"special":
			return _special(p)
		"fall":
			return _fall(p)
	return _st("idle")


func _strike(tx: String, p: float, a: float, b: float, lunge: float, wind_rot: float, hit_rot: float) -> Dictionary:
	if p < a:
		var w := _ss(0.0, a, p)
		return _st("idle", Vector2(lerpf(0.0, -8.0, w), 0.0), lerpf(0.0, wind_rot, w), Vector2(1.0, lerpf(1.0, 0.985, w)))
	if p < b:
		var w2 := _ss(a, a + 0.1, p)
		return _st(tx, Vector2(lerpf(0.0, lunge, w2), 0.0), lerpf(wind_rot, hit_rot, w2))
	var w3 := _ss(b, 1.0, p)
	return _st("idle", Vector2(lerpf(lunge * 0.5, 0.0, w3), 0.0), lerpf(hit_rot, 0.0, w3))


func _special(p: float) -> Dictionary:
	match special_type:
		"slipper":
			if p < 0.3:
				var w := _ss(0.0, 0.3, p)
				return _st("idle", Vector2(lerpf(0.0, -10.0, w), 0.0), lerpf(0.0, -0.12, w), Vector2(1.0, lerpf(1.0, 0.96, w)))
			if p < 0.74:
				return _st("punch", Vector2(8.0, 0.0), 0.05)
			return _st("idle", Vector2(lerpf(8.0, 0.0, _ss(0.74, 1.0, p)), 0.0))
		"slam":
			if p < 0.3:
				var w2 := _ss(0.0, 0.3, p)
				return _st("idle", Vector2.ZERO, lerpf(0.0, -0.05, w2), Vector2(lerpf(1.0, 1.06, w2), lerpf(1.0, 0.9, w2)))
			if p < 0.47:
				var q := (p - 0.3) / 0.17
				return _st("kick", Vector2(lerpf(0.0, 24.0, q), -110.0 * sin(PI * q)), lerpf(-0.05, 0.08, q))
			if p < 0.62:
				return _st("idle", Vector2(8.0, 0.0), 0.0, Vector2(1.08, 0.88))
			var w3 := _ss(0.62, 1.0, p)
			return _st("idle", Vector2(lerpf(8.0, 0.0, w3), 0.0), 0.0, Vector2(lerpf(1.08, 1.0, w3), lerpf(0.88, 1.0, w3)))
		_:
			if p < 0.12:
				var w4 := _ss(0.0, 0.12, p)
				return _st("idle", Vector2(lerpf(0.0, -8.0, w4), 0.0), lerpf(0.0, -0.1, w4), Vector2(1.0, lerpf(1.0, 0.95, w4)))
			if p < 0.82:
				return _st("punch", Vector2(14.0, 0.0), 0.14)
			return _st("idle", Vector2(lerpf(14.0, 0.0, _ss(0.82, 1.0, p)), 0.0), lerpf(0.14, 0.0, _ss(0.82, 1.0, p)))


func _fall(p: float) -> Dictionary:
	var lay := -cw * 0.42
	var keys := [
		[0.0, Vector2(-10.0, 0.0), -0.17],
		[0.25, Vector2(-45.0, -70.0), -0.75],
		[0.5, Vector2(-85.0, -22.0), -1.5],
		[0.62, Vector2(-95.0, lay), -1.5708],
		[0.7, Vector2(-98.0, lay - 14.0), -1.5708],
		[0.8, Vector2(-98.0, lay), -1.5708],
		[1.0, Vector2(-98.0, lay), -1.5708],
	]
	for i in range(1, keys.size()):
		var k1: Array = keys[i]
		if p <= float(k1[0]) or i == keys.size() - 1:
			var k0: Array = keys[i - 1]
			var w := _ss(float(k0[0]), float(k1[0]), p)
			return _st("idle", Vector2(k0[1]).lerp(Vector2(k1[1]), w), lerpf(float(k0[2]), float(k1[2]), w))
	return _st("idle")


func _update() -> void:
	if spr == null:
		return
	var s := _pose()
	var tx: Texture2D = tex[s["tex"]]
	if spr.texture != tx:
		spr.texture = tx
	var tw := float(tx.get_width())
	spr.offset = Vector2(-tw * 0.5, -float(tx.get_height()))
	spr.position = s["pos"]
	spr.rotation = s["rot"]
	spr.scale = s["sc"]
	spr.self_modulate = s["mod"]
